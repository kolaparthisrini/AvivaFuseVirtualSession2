package com.caps;

import javax.jws.WebService;

@WebService
public interface ChangeStudent {
  Student changeName(Student student);
}